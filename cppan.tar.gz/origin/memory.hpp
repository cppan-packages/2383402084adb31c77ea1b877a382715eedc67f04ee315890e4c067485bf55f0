// Copyright (c) 2009-2015 Andrew Sutton
// All rights reserved

#ifndef ORIGIN_RANGES
#define ORIGIN_RANGES

// Support for allocators.
#include <origin/memory/allocator.hpp>

// Generic construct/destroy.
#include <origin/memory/memory.hpp>

#endif
